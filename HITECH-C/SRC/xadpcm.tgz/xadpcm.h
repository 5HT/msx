/********************************************************/
/* File  : xadpcm.h					*/
/* Author: Alex Wulms					*/
/* Date  : 16 July 1996					*/
/********************************************************/

typedef struct _AdpcmParams {
  unsigned sample_predictor;
  unsigned delta_n;
} AdpcmParams;

#ifdef _ANSI_C_
extern void pcm2adp(char *outbuf, char *inbuf, unsigned n);
extern void adp2pcm(char *outbuf, char *inbuf, unsigned n);
extern void init_adpcmpcm(AdpcmParams *adpcm_params);
extern char pcm_adpcm(char pcm_value, AdpcmParams *adpcm_params);
extern char adpcm_pcm(char adpcm_value, AdpcmParams *adpcm_params);
#else
extern void pcm2adp();
extern void adp2pcm();
extern void init_adpcmpcm();
extern char pcm_adpcm();
extern char adpcm_pcm();
#endif

