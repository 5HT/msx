/************************************************/
/* File  : pcm2adp.c				*/
/* Author: Alex Wulms				*/
/* Date  : 7-16-1996				*/
/*						*/
/* This program may be distributed in unmodified*/
/* form only					*/
/************************************************/
#include <stdio.h>
#include <fcntl.h>

#include "xadpcm.h"

#define H_BUFSIZE 0x2000
#ifndef O_BINARY
#define O_BINARY 0
#endif

void main(argc, argv)
int argc;
char *argv[];
{
  int pcm_fd, adpcm_fd;
  char buf[H_BUFSIZE*2];
  char adpcm_value;
  unsigned cnt;
  char *inbuf_ptr, *outbuf_ptr;
  AdpcmParams adpcm_params;

  printf("PCM to ADPCM conversion 1.0. Copyright 1996 XelaSoft\n");

  if (argc != 3) {
    printf("use\n%s <pcmfile> <adpcmfile>\n", argv[0]);
    printf("to convert <pcmfile> to <adpcmfile>\n");
    exit(1);
  }

  if ((pcm_fd = open(argv[1], O_RDONLY | O_BINARY)) == -1) {
    printf("Error opening %s\n", argv[1]);
    exit(1);
  } 
  if ((adpcm_fd = open(argv[2], O_CREAT | O_TRUNC | O_RDWR | O_BINARY, 0600)) == -1) {
    printf("Error creating %s\n", argv[2]);
    exit(1);
  }

  printf("Pcm to adpcm conversion started\n");
  init_adpcmpcm(&adpcm_params);
  while ((cnt = read(pcm_fd, buf, H_BUFSIZE<<1)>>1)) {
    inbuf_ptr = buf;
    outbuf_ptr = buf;
    while (cnt--) {
      adpcm_value = pcm_adpcm(*inbuf_ptr++, &adpcm_params);
      *outbuf_ptr++ = (adpcm_value<<4) | 
                      pcm_adpcm(*inbuf_ptr++, &adpcm_params);
    }
    write(adpcm_fd, buf, outbuf_ptr - buf);
  }
  close(pcm_fd);
  close(adpcm_fd);
  printf("Pcm to adpcm conversion completed\n");
  exit(0);
}

