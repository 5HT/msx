/************************************************/
/* File  : adp2pcm.c				*/
/* Author: Alex Wulms				*/
/* Date  : 7-16-1996				*/
/*						*/
/* This program may be distributed in unmodified*/
/* form only					*/
/************************************************/
#include <stdio.h>
#include <fcntl.h>

#include "xadpcm.h"

#define H_BUFSIZE 0x2000
#ifndef O_BINARY
#define O_BINARY 0
#endif

void main(argc, argv)
int argc;
char *argv[];
{
  int adpcm_fd, pcm_fd;
  char buf[H_BUFSIZE*2];
  char adpcm_value;
  unsigned cnt;
  char *inbuf_ptr, *outbuf_ptr;
  AdpcmParams adpcm_params;

  printf("ADPCM to PCM conversion 1.0. Copyright 1996 XelaSoft\n");

  if (argc != 3) {
    printf("use\n%s <adpcmfile> <pcmfile>\n", argv[0]);
    printf("to convert <adpcmfile> to <pcmfile>\n");
    exit(1);
  }

  if ((adpcm_fd = open(argv[1], O_RDONLY | O_BINARY)) == -1) {
    printf("Error opening %s\n", argv[1]);
    exit(1);
  } 
  if ((pcm_fd = open(argv[2], O_CREAT | O_TRUNC | O_RDWR | O_BINARY, 0600)) == -1) {
    printf("Error creating %s\n", argv[2]);
    exit(1);
  }

  printf("Adpcm to pcm conversion started\n");
  init_adpcmpcm(&adpcm_params);
  while ((cnt = read(adpcm_fd, buf+H_BUFSIZE, H_BUFSIZE))) {
    inbuf_ptr = buf+H_BUFSIZE;
    outbuf_ptr = buf;
    while (cnt--) {
      adpcm_value = *inbuf_ptr++;
      *outbuf_ptr++ = adpcm_pcm(adpcm_value>>4, &adpcm_params);
      *outbuf_ptr++ = adpcm_pcm(adpcm_value, &adpcm_params);
    }
    write(pcm_fd, buf, outbuf_ptr - buf);
  }
  close(adpcm_fd);
  close(pcm_fd);
  printf("Adpcm to pcm conversion completed\n");
  exit(0);
}

