/********************************************************/
/* ADPCM and PCM conversion routines			*/
/* Copyright (c) 1996 XelaSoft				*/
/*   A. Wulms						*/
/*   Oude Singel 206					*/
/*   2312 RJ Leiden (The Netherlands)			*/
/* email: A.P.Wulms@inter.nl.net			*/
/*							*/
/* These routines may be freely used by any means as	*/
/* long as you mention in your programs	that you have	*/
/* made use of XelaSoft ADPCM and PCM conversion	*/
/* routines (XADPCM for short)				*/
/*							*/
/* The following routines are provided:			*/
/*							*/
/* Convert a PCM sample into an ADPCM sample		*/
/*   void pcm2adp(outbuf, inbuf, n)			*/
/*   char *outbuf : PCM buffer				*/
/*   char *inbuf  : ADPCM buffer			*/
/*   unsigned n   : #ADPCM bytes to process		*/
/*							*/
/* Convert an ADPCM sample into a PCM sample		*/
/*   void adp2pcm(outbuf, inbuf, n)			*/
/*   char *outbuf : ADPCM buffer			*/
/*   char *inbuf  : PCM buffer				*/
/*   unsigned n   : #ADPCM bytes to process		*/
/*							*/
/* Initialize PCM to ADPCM conversion and vice		*/
/* versa						*/
/*   void init_adpcmpcm(adpcm_params)			*/
/*     AdpcmParams *adpcm_params : conversion params	*/
/*							*/
/* Convert one PCM code into one ADPCM code		*/
/*   char pcm_adpcm(pcm_value, adpcm_params)		*/
/*   char pcm_value            : value to be converted	*/
/*   AdpcmParams *adpcm_params : conversion params	*/
/*							*/
/* Convert one ADPCM code into one PCM code		*/
/*   char adpcm_pcm(adpcm_value, adpcm_params)		*/
/*   char adpcm_value           : value to be converted	*/
/*   AdpcmParams *adpcm_params : conversion params	*/
/*							*/
/* The PCM data are in 8 bit unsigned format, they 	*/
/* fluctuate round 0x80					*/
/* The ADPCM data are in (packed) 4 bit format. It is	*/
/* the format which is used by the MSX AUDIO processor,	*/
/* which can be found, in among other, the Philips Music*/
/* Module. It is not compatible with the 4 bit format of*/
/* the Soundblaster and compatible soundcards		*/
/*							*/
/* Note: MSX, Soundblaster and Philips are (registered)	*/
/* trademarks of their respective owners		*/
/********************************************************/

typedef struct _AdpcmParams {
  unsigned sample_predictor;
  unsigned delta_n;
} AdpcmParams;

/************************************************/
/* Function prototypes				*/
/************************************************/
#ifdef _ANSI_C_
void pcm2adp(char *outbuf, char *inbuf, unsigned n);
void adp2pcm(char *outbuf, char *inbuf, unsigned n);
void init_adpcmpcm(AdpcmParams *adpcm_params);
char pcm_adpcm(char pcm_value, AdpcmParams *adpcm_params);
char adpcm_pcm(char adpcm_value, AdpcmParams *adpcm_params);
#else
void pcm2adp();
void adp2pcm();
void init_adpcmpcm();
char pcm_adpcm();
char adpcm_pcm();
#endif

/************************************************/
/* Convert an 8 bit unsigned PCM sample into a	*/
/* 4 bit ADPCM sample				*/
/************************************************/
#ifdef _ANSI_C_
void pcm2adp(char *outbuf, char *inbuf, unsigned n)
#else
void pcm2adp(outbuf, inbuf, n)
char *outbuf;
char *inbuf;
unsigned n;
#endif
{
  AdpcmParams adpcm_params;
  char tmp_adpcm;

  init_adpcmpcm(&adpcm_params);
  while (n--) {
    tmp_adpcm = pcm_adpcm(*inbuf++, &adpcm_params);
    *outbuf++ = (tmp_adpcm << 4) | pcm_adpcm(*inbuf++, &adpcm_params);
  }
}

/************************************************/
/* Convert a 4 bit ADPCM sample into an 8 bit	*/
/* unsigned PCM sample 				*/
/************************************************/
#ifdef _ANSI_C_
void adp2pcm(char *outbuf, char *inbuf, unsigned n)
#else
void adp2pcm(outbuf, inbuf, n)
char *outbuf;
char *inbuf;
unsigned n;
#endif
{
  char tmp_adpcm;
  AdpcmParams adpcm_params;

  init_adpcmpcm(&adpcm_params);
  while (n--) {
    tmp_adpcm = *inbuf++;
    *outbuf++ = adpcm_pcm(tmp_adpcm>>4, &adpcm_params);
    *outbuf++ = adpcm_pcm(tmp_adpcm, &adpcm_params);
  }
}

/************************************************/
/* Initialize the conversion parameters		*/
/************************************************/
#ifdef _ANSI_C_
void init_adpcmpcm(AdpcmParams *adpcm_params)
#else
void init_adpcmpcm(adpcm_params)
AdpcmParams *adpcm_params;
#endif
{
  adpcm_params->sample_predictor = 0x8000;
  adpcm_params->delta_n = 0x007f;
}


/************************************************/
/* Convert a PCM code into an ADPCM code	*/
/************************************************/
#ifdef _ANSI_C_
char pcm_adpcm(char pcm_value, AdpcmParams *adpcm_params)
#else
char pcm_adpcm(pcm_value, adpcm_params)
char pcm_value;
AdpcmParams *adpcm_params;
#endif
{
  unsigned pcm_x_256;
  unsigned delta_sample;
  unsigned wrk_delta_n;
  char adpcm_value;

  /* Calculate the difference between the predicted pcm value */
  /* and the real pcm value and set the sign bit of the       */
  /* adpcm value					      */
  if ((pcm_x_256 = ((unsigned char)pcm_value)<<8) >= adpcm_params->sample_predictor) {
    delta_sample = pcm_x_256 - adpcm_params->sample_predictor;
    adpcm_value = 0;
  }
  else {
    delta_sample = adpcm_params->sample_predictor - pcm_x_256;
    adpcm_value = 8;
  }

  /* Calculate the new adpcm value.            */
  wrk_delta_n = adpcm_params->delta_n;
  if (delta_sample >= wrk_delta_n) {
    delta_sample -= wrk_delta_n;
    adpcm_value |= 4;
  }
  wrk_delta_n >>= 1;
  if (delta_sample >= wrk_delta_n) {
    delta_sample -= wrk_delta_n;
    adpcm_value |= 2;
  }
  wrk_delta_n >>= 1;
  if (delta_sample >= wrk_delta_n)
    adpcm_value |= 1;

  /* calculate new delta_n, sample_predictor */
  adpcm_pcm(adpcm_value, adpcm_params);

  return adpcm_value;
}

/************************************************/
/* Convert an ADPCM code into a PCM code	*/
/************************************************/
#ifdef _ANSI_C_
char adpcm_pcm(char adpcm_value, AdpcmParams *adpcm_params)
#else
char adpcm_pcm(adpcm_value, adpcm_params)
char adpcm_value;
AdpcmParams *adpcm_params;
#endif
{
  unsigned old_delta_n = adpcm_params->delta_n;
  unsigned wrk_delta_n = old_delta_n;
  static unsigned char factors[] = { 0x39, 0x39, 0x39, 0x39,
                                     0x4d, 0x66, 0x80, 0x99 };
  unsigned char factor; 
  unsigned cnt;

  wrk_delta_n >>= 1;
  if (adpcm_value & 1)
    wrk_delta_n += old_delta_n;
  wrk_delta_n >>= 1;
  if (adpcm_value & 2)
    wrk_delta_n += old_delta_n;
  wrk_delta_n >>= 1;
  if (adpcm_value & 4)
    wrk_delta_n += old_delta_n;

  if (adpcm_value & 8)
    if (adpcm_params->sample_predictor > wrk_delta_n)
      adpcm_params->sample_predictor -= wrk_delta_n;
    else
      adpcm_params->sample_predictor = 0;
  else
    if (0xffff-wrk_delta_n > adpcm_params->sample_predictor)
      adpcm_params->sample_predictor += wrk_delta_n;
    else
      adpcm_params->sample_predictor = 0xffff;

  if (sizeof(unsigned)<4) {
    /* use combined multiply/divide loop to prevent */
    /* overflow on an 8/16-bit architecture */
    factor = factors[adpcm_value & 7];
    wrk_delta_n = 0;
    for (cnt = 6; cnt; cnt--) {
      if (factor & 1)
        wrk_delta_n += old_delta_n;
      wrk_delta_n >>= 1;
      factor >>= 1;
    }
    if (factor & 1)
      wrk_delta_n += old_delta_n;
    factor >>= 1;
    if (factor & 1)
      wrk_delta_n += (old_delta_n << 1);
  }
  else
    /* 32bit range is large enough, so use (faster)    */
    /* processor instructions. On a 486DX2, this gives */
    /* a speed-up of approximately 30%                 */
    wrk_delta_n = (adpcm_params->delta_n * factors[adpcm_value & 7])>>6;

  /* Clip delta_n against the upper/lower bounds */
  if (wrk_delta_n > 0x6000)
    adpcm_params->delta_n = 0x6000;
  else
    if (wrk_delta_n < 127)
      adpcm_params->delta_n = 127;
    else
      adpcm_params->delta_n = wrk_delta_n;

  /* PCM value is predicted pcm value/256 */
  return adpcm_params->sample_predictor>>8;
}
